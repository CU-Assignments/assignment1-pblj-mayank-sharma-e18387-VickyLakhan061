show databases;
use banksystem;
show tables;
select * from signup;
truncate table signup;

create table signuptwo(Form_no varchar(30),Religion varchar(30),Category varchar(30),Income varchar(30),Education varchar(30),
Occupation varchar(30),PAN varchar(30),Aadhar varchar(30),Senior_Citizen varchar(30),Existing_account varchar(30));
select * from signuptwo;
truncate table signuptwo;

create table signupthree(form_no varchar(30),Account_Type varchar(40),Card_No varchar(30),Pin varchar(30),Facility varchar(200));
select * from signupthree;
truncate table signupthree;

create table login(formno varchar(30),Card_No varchar(30),Pin varchar(30));
select * from login;
truncate table login;
drop table login;

create table bank(Pin varchar(30),Date varchar(30),Type varchar(30),Amount varchar(30));
select * from bank;
truncate table bank;
